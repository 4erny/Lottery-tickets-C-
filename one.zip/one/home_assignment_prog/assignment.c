#include <stdio.h>     //libraries.
#include <stdlib.h>
#include <time.h>

void func1();          // functions which i'll use.
void func2();
void func3();
void func4();
void func5();

void main()            // main body function.
{
	int  a, b;         //variables for loops.
	int  x, y, z=0;    //variables for loops.
	int  winners4=0, winners3=0;    //persons who guesed 4 and 3 numbers.
	
	int  arr1[4];                   //1 dimensional array, massive.
	int  arr2[20000][5];            //2 dimensional array, massive.

	int budjet;              //variable for budjet.

	int win3, win4;        //this is used to show the exact winning amount for each person, i wanted to use float, but in my case int is pretty good.

	char arr3[5];            //massive used in comparing beetwen winning ticket and tickets of people.

	FILE *f;               //create a file.

	srand(time(0));          //random.

	printf("enter amount of budjet\n");    //we can insert a budjet for our lottery.
	scanf("%d", &budjet);

	func1();                              // use of our functions, step by step.
	func2();
	func3();
	func4();
	func5();

	for (a=0;a<4;a++)                       // creating 4 unigue numbers for winning ticket by using comparing.
	{
		arr1[a]=rand()%25+1;
		for (b=0;b<a;b++)
		{
			if (arr1[a]==arr1[b])
			{
				a--;                          //if everything is fine continue if no, stop and start again from the previous one.
				break;
			}
		}
	}

	for (a=0; a<4; a++)                     //  checking our 4 unique numbers.
	{
	printf("%d; ",arr1[a]);
	}
	
	f=fopen("file1.txt","r");	           // opening a file where 20000 tickets already created and converting from characters into int by using atoi(asci to integer).
	
	for(x = 0;x<20000;x++)		
	{
		for(y = 0;y<5;y++)
		{
			fscanf(f,"%s",arr3);        //i used fscanf because it's easier, because if i'll use gets, i should write a small command for eacha character after any symbol except of numbers.
			arr2[x][y] = atoi(arr3);
		//	printf("%d ",arr2[x][y]);     // i can show all tickets, but in my opiniot it's usels.
		}
		//printf("\n");    //to change the line.
	}

	fclose(f);
	
	for (a=0; a<20000; a++)
	{
		for (b=0; b<5; b++)
		{ 
			for (x=0; x<4; x++)
			{
				if (arr2[a][b] == arr1[x])
				{
					z++;
					break;                           //z's our counter of winning tickets(people who won), we add z after cheaking all 4 winning numbers with 5 numbers in each ticket.
				}
			}
		}
		
	
	if (z == 4)                                       //if we have 4 similar numbers in one ticket we count/add 1 winner4.
	{
	winners4++;
	}
	if (z == 3)                                       //if we have 3 similar numbers in one ticket we count/add 1 winner3.
	{
	winners3++;
	}
	z=0;
	}

	f=fopen("file2.txt","r");	           
	
	for(x = 0;x<20000;x++)		
	{
		for(y = 0;y<5;y++)
		{
			fscanf(f,"%s",arr3);
			arr2[x][y] = atoi(arr3);
		}
	}
	fclose(f);
	
	for (a=0; a<20000; a++)
	{
		for (b=0; b<5; b++)
		{ 
			for (x=0; x<4; x++)
			{
				if (arr2[a][b] == arr1[x])
				{
					z++;
					break;
				}
			}
		}
		
	
	if (z == 4)
	{
	winners4++;
	}
	if (z == 3)
	{
	winners3++;
	}
	z=0;
	}

	f=fopen("file3.txt","r");	

	for(x = 0;x<20000;x++)		
	{
		for(y = 0;y<5;y++)
		{
			fscanf(f,"%s",arr3);
			arr2[x][y] = atoi(arr3);
		}
	}
	fclose(f);
	
	for (a=0; a<20000; a++)
	{
		for (b=0; b<5; b++)
		{ 
			for (x=0; x<4; x++)
			{
				if (arr2[a][b] == arr1[x])
				{
					z++;
					break;
				}
			}
		}
		
	
	if (z == 4)
	{
	winners4++;
	}
	if (z == 3)
	{
	winners3++;
	}
	z=0;
	}

	f=fopen("file4.txt","r");	 

	for(x = 0;x<20000;x++)		
	{
		for(y = 0;y<5;y++)
		{
			fscanf(f,"%s",arr3);
			arr2[x][y] = atoi(arr3);
		}
	}
	fclose(f);
	
	for (a=0; a<20000; a++)
	{
		for (b=0; b<5; b++)
		{ 
			for (x=0; x<4; x++)
			{
				if (arr2[a][b] == arr1[x])
				{
					z++;
					break;
				}
			}
		}
		
	
	if (z == 4)
	{
	winners4++;
	}
	if (z == 3)
	{
	winners3++;
	}
	z=0;
	}

	f=fopen("file5.txt","r");	  

	for(x = 0;x<20000;x++)		
	{
		for(y = 0;y<5;y++)
		{
			fscanf(f,"%s",arr3);
			arr2[x][y] = atoi(arr3);
		}
	}
	fclose(f);
	
	for (a=0; a<20000; a++)
	{
		for (b=0; b<5; b++)
		{ 
			for (x=0; x<4; x++)
			{
				if (arr2[a][b] == arr1[x])
				{
					z++;
					break;
				}
			}
		}
		
	
	if (z == 4)
	{
	winners4++;
	}
	if (z == 3)
	{
	winners3++;
	}
	z=0;
	}
	
printf("\namount of people who guesed 4 right numbers : %d\namount of people who guesed 3 right numbers : %d\n", winners4, winners3);  //shows us how many winners in both categories we have.

win3 = (budjet/100)*30/winners3;      //split our budjet between people. Do it like a brother :)
win4 = (budjet/100)*70/winners4;

printf("amount of prise for 4 right answers for each person : %d\namount of prise for 3 right answers for each person : %d\n ", win4, win3);               //shows amount of each winning.
}

void func1()                       // create 5 unique numbers in each of 20000 tickets, by using 2 dimensional arrays/massive, and comparing.
{
	static int arr[20000][5];    //Using static inside a function is the easiest. This simply means that after the variable is initialized, it remains in memory until the end of the program.
	int a=0,b=0,c,y,x;
	FILE *f;

	for (a=0; a<20000; a++)
	{
		for (b=0; b<5; b++)
		{
			arr[a][b] = rand()%25+1;
			for (c=0; c<b; c++)
			{
				if (arr[a][b] == arr[a][c])
				{
					a--;
					break;
				}
			}
		}
	}
	
	f = fopen("file1.txt","w"); // write my tickets in file.
	for(y=0;y<20000;y++)
	{
		for(x=0;x<5;x++)
		{
			fprintf(f,"\t%d",arr[y][x]); //     \t is like space. instead of \t we can use space.
		}
		fprintf(f,"\n");
	}
	fclose(f);
}
void func2()                        // create 5 unique numbers in each of 20000 tickets, by using 2 dimensional arrays/massive, and comparing.
{
	static int arr[20000][5];
	int a=0,b=0,c,y,x;
	FILE *f;

	for (a=0; a<20000; a++)
	{
		for (b=0; b<5; b++)
		{
			arr[a][b] = rand()%25+1;
			for (c=0; c<b; c++)
			{
				if (arr[a][b] == arr[a][c])
				{
					a--;
					break;
				}
			}
		}
	}
	
	f = fopen("file2.txt","w");
	for(y=0;y<20000;y++)
	{
		for(x=0;x<5;x++)
		{
			fprintf(f,"\t%d",arr[y][x]);
		}
		fprintf(f,"\n");
	}
	fclose(f);
}

void func3()                                       // create 5 unique numbers in each of 20000 tickets, by using 2 dimensional arrays/massive, and comparing.
{
	static int arr[20000][5];
	int a=0,b=0,c,y,x;
	FILE *f;

	for (a=0; a<20000; a++)
	{
		for (b=0; b<5; b++)
		{
			arr[a][b] = rand()%25+1;
			for (c=0; c<b; c++)
			{
				if (arr[a][b] == arr[a][c])
				{
					a--;
					break;
				}
			}
		}
	}
	
	f = fopen("file3.txt","w");
	for(y=0;y<20000;y++)
	{
		for(x=0;x<5;x++)
		{
			fprintf(f,"\t%d",arr[y][x]);
		}
		fprintf(f,"\n");
	}
	fclose(f);
}
void func4()                        // create 5 unique numbers in each of 20000 tickets, by using 2 dimensional arrays/massive, and comparing.
{
	static int arr[20000][5];
	int a=0,b=0,c,y,x;
	FILE *f;

	for (a=0; a<20000; a++)
	{
		for (b=0; b<5; b++)
		{
			arr[a][b] = rand()%25+1;
			for (c=0; c<b; c++)
			{
				if (arr[a][b] == arr[a][c])
				{
					a--;
					break;
				}
			}
		}
	}
	
	f = fopen("file4.txt","w");
	for(y=0;y<20000;y++)
	{
		for(x=0;x<5;x++)
		{
			fprintf(f,"\t%d",arr[y][x]);
		}
		fprintf(f,"\n");
	}
	fclose(f);
}
void func5()                                           // create 5 unique numbers in each of 20000 tickets, by using 2 dimensional arrays/massive, and comparing.
{
	static int arr[20000][5];
	int a=0,b=0,c,y,x;
	FILE *f;

	for (a=0; a<20000; a++)
	{
		for (b=0; b<5; b++)
		{
			arr[a][b] = rand()%25+1;
			for (c=0; c<b; c++)
			{
				if (arr[a][b] == arr[a][c])
				{
					a--;
					break;
				}
			}
		}
	}
	
	f = fopen("file5.txt","w");
	for(y=0;y<20000;y++)
	{
		for(x=0;x<5;x++)
		{
			fprintf(f,"\t%d",arr[y][x]);
		}
		fprintf(f,"\n");
	}
	fclose(f);
}